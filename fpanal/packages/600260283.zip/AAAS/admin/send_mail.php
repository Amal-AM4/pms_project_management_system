<?php
	header('location:send.php');
?>